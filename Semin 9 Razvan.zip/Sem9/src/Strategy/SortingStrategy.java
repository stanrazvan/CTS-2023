package Strategy;

public interface SortingStrategy {
    void sort(int[] array);
}
