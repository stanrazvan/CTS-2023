package Composite;

public interface Component {
    void render();
}
