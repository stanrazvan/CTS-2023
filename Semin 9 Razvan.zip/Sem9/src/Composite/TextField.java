package Composite;

public class TextField implements Component{
    @Override
    public void render() {
        System.out.println("Se afiseaza campul de text");
    }
}
