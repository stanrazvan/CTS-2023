package clase;
public class XmlParser {
    public void parseXml(String xml){
        //gjjj
    }
}
