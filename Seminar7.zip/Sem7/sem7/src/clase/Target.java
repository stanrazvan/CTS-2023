package clase;
public interface Target {
    void request();
}
