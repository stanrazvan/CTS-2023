package clase;

public class XmlToJsonAdapter {
    private XmlParser = xmlParser;

    public XmlToJsonAdapter(XmlParser xmlParser){
        thi
    }

}