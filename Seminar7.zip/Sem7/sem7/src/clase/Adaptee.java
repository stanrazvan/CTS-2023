package clase;
public class Adaptee {
    public void specificRequest(){
        System.out.println("Adaptee specific request");
    }
}
