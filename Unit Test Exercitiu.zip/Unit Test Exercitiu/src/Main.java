

public class Main {
    public Main() {
    }

    public static void main(String[] args) {
    }
}