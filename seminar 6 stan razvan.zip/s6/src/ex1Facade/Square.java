package ex1Facade;

public class Square {
    public void draw() {
        System.out.println("Patratul este desenat");
    }
}
