package ex2Facade;

public class MasinaSport {
    public void descriere() {
        System.out.println("Masina este sport");
    }
}
