package ex2Facade;

public class MasinaFamilie {
    public void descriere() {
        System.out.println("Masina este de familie");
    }
}
