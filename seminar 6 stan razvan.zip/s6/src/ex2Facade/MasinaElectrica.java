package ex2Facade;

public class MasinaElectrica {
    public void descriere() {
        System.out.println("Masina este electrica");
    }
}
