package Adapter2;

public class XmlParser {
    public void parseXml(String xml) {

    }
}
