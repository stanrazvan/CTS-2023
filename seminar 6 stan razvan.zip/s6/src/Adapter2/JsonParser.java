package Adapter2;

public interface JsonParser {
    void parseJson(String json);
}
