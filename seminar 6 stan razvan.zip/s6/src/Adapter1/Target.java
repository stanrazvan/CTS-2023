package Adapter1;

public interface Target {
    void request();
}
