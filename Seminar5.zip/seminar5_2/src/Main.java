public class Main {
    public static void main(String[] args) {


        AnimalFactory af1 = new DogFactory();
        Animal dog = af1.createAnimal();
        dog.speak();
        AnimalFactory af2 = new CatFactory();
        Animal cat = af2.createAnimal();
        cat.speak();
        AnimalFactory af3 = new GirafaFactory();
        Animal girafa = af3.createAnimal();
        girafa.speak();
    }
}

