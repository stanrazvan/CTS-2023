public class Girafa implements Animal{

    public void speak() {
        System.out.println("I am Girafa");
    }
}
