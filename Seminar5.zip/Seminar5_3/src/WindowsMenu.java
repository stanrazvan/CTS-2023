public class WindowsMenu implements Menu {
    @Override
    public void show() {
        System.out.println("Showing a Windows style menu.");
    }
}