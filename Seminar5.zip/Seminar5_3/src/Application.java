public class Application {
    private GUIFactory guiFactory;
    private Button button;
    private Menu menu;

    public Application(GUIFactory guiFactory) {
        this.guiFactory = guiFactory;
        this.button = guiFactory.createButton();
        this.menu = guiFactory.createMenu();
    }

    public void createUI() {
        this.button.paint();
        this.menu.show();
    }
}