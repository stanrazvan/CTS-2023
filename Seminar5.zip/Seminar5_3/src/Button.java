public interface Button {
    void paint();
}