public class MacButton implements Button{
    public void paint() {
        System.out.println("Painting a Mac style button.");
    }
}
