public interface Menu {
    void show();
}