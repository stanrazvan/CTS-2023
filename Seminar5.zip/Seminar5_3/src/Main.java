public class Main {
    public static void main(String[] args) {
       
        GUIFactory windowsFactory = new WindowsGUIFactory();
        Application app = new Application(windowsFactory);
        app.createUI();


        GUIFactory macFactory = new MacGUIFactory();
        app = new Application(macFactory);
        app.createUI();
    }
}


