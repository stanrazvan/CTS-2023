public class MacMenu implements Menu {
    @Override
    public void show() {
        System.out.println("Showing a macOS style menu.");
    }
}