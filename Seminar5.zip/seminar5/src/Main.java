public class Main {
    public static void main(String[] args) {
        Pizza pizza1 = PizzaFactory.createPizza("cheese");
        pizza1.prepare();

        Pizza pizza2 = PizzaFactory.createPizza("pepperoni");
        pizza2.prepare();
    }
}