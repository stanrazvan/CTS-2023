public abstract class Pizza {
    public abstract void prepare();
}