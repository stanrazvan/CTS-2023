public abstract class Vehicle {
    double value;

    public double getValue() {
        return value;
    }
    public void setValue(double value) {
        this.value = value;
    }
    public double calculateValue()
    {
        return  this.value *0.5;
    }
}