public class Main {
    public static void main(String[] args) {
        Server server = Server.getInstance(8080, "Server1");
        /*String status = server.showStatus(server.portNumber, server.nume);
        System.out.println(status);*/

    }
}

/*public class server
{
singeleton =  peste tot este un singur obiect creat si transmis ca referinta peste tot.
trebuie sa existe o instana statica, avem  nevoi de o metoda care sa apeleze si impelenteze instanta si
constructorii trebuie sa fie privati
    int portnumber;
    String nume;
    private static server instance; //trb sa fie statica penntru a nu fi apelata din orice alt loc

}
    Server(instance...)
 public static server
 { - constructor
  - verficiare instanta a fost creata sau apelata anterior

  - daca este prima accesare => server.instance = new server; return server.instance

  - daca nu e prima accesare => returnare server.instance

  peblic String showStatus{
  returneaza "serverul (nume)  ruleaza pe portul
  }
 }
  */
