public class Server {
    private static Server instance; // instanța statică pentru singleton
    private int portNumber;
    private String nume;
    private Server(int portNumber, String nume) {
        this.portNumber = portNumber;
        this.nume = nume;
    }
    public static Server getInstance(int portNumber, String nume){
        if(instance ==null) {
                instance = new Server(portNumber,nume);
        }
        return Server.instance;
    }
    public String showStatus(int portNumber, String nume){
       return "Serverul "+nume+"ruleaza pe portul: "+portNumber;
    }
}
