package clase;

public interface Subscription {
    String getDescription();
    double getPrice();
}
