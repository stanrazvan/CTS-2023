package clase;

public class BasicSubscription implements Subscription{
    @Override
    public String getDescription(){
        return "Abonament de baza";
    }
    @Override
    public double getPrice(){
        return 10.0;
    }
}
