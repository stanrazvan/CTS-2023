import java.util.Arrays;

/*- o companie care produce masini si avem nevoie de un numar mare de masini, dar care sa aiba aceleasi caracteristizici de baza dar
personalizate diferit pt fiecare client( cum ar fi culoari, optiuni, interior).*/
public class Main {
    public static void main(String[] args) {

        CarPrototype car = CarFactory.createCar("standard");
        car.setColor("red");
        car.setOptions(Arrays.asList("sunroof", "navigation"));
        car.setInterior("leather");
        car.printDetails();

        CarPrototype car2 = CarFactory.createCar("sport");
        car2.setColor("black");
        car2.setOptions(Arrays.asList("exhaust", "navigation"));
        car2.setInterior("leather");
        car2.printDetails();

        CarPrototype car3 = CarFactory.createCar("basic");
        car3.setColor("black");
        car3.setOptions(Arrays.asList("exhaust", "navigation"));
        car3.setInterior("leather");
        car3.printDetails();
    }
}