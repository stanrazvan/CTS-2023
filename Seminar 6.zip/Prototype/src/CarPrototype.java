import java.util.List;

public interface CarPrototype {
    CarPrototype clone();
    void setColor(String color);
    void setOptions(List<String> options);
    void setInterior(String interior);
    void printDetails();
}