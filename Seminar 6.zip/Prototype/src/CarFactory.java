import java.util.HashMap;
import java.util.Map;

public class CarFactory {
    private static Map<String, CarPrototype> prototypes = new HashMap<>();

    static {
        prototypes.put("standard", new Car("Toyota", "Corolla", 2021));
        prototypes.put("sport", new Car("Ford", "Mustang", 2022));
    }

    public static CarPrototype createCar(String type) {
        CarPrototype prototype = prototypes.get(type);
        if (prototype == null) {
            throw new IllegalArgumentException("Invalid car type: " + type);
        }
        return prototype.clone();
    }
}