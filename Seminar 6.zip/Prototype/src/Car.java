import java.util.ArrayList;
import java.util.List;

public class Car implements CarPrototype{

    private String make;
    private String model;
    private int year;
    private String color;
    private List<String> options;
    private String interior;

    public Car(String make, String model, int year) {
        this.make = make;
        this.model = model;
        this.year = year;
        this.color = "black";
        this.options = new ArrayList<>();
        this.interior = "standard";
    }

    public Car(Car other) {

        this.make = other.make;
        this.model = other.model;
        this.year = other.year;
        this.color = other.color;
        this.options = new ArrayList<>(other.options);
        this.interior = other.interior;
    }

    @Override
    public CarPrototype clone() {
        return new Car(this);
    }

    @Override
    public void setColor(String color) {
        this.color = color;
    }

    @Override
    public void setOptions(List<String> options) {
        this.options = options;
    }

    @Override
    public void setInterior(String interior) {
        this.interior = interior;
    }

    @Override
    public void printDetails() {
        System.out.println(make + " " + model + " (" + year + ")");
        System.out.println("Color: " + color);
        System.out.println("Options: " + options);
        System.out.println("Interior: " + interior);
    }
}
